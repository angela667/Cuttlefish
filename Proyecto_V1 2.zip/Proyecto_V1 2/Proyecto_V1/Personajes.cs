﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_V1
{
    //Crear una base de datos con todos personajes jugables
    //Añadir datos como Vida/Salud, Energia/Poder, Ataques especiales si tiene
    internal class Personajes
    {
    }
}

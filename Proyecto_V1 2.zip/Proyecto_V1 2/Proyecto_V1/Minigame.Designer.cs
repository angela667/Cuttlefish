﻿namespace Proyecto_V1
{
    partial class Minigame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.ControlLbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(102, 376);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(226, 69);
            this.button1.TabIndex = 0;
            this.button1.Text = "HOW MANY LETTERS DOES MY NAME HAVE?";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(482, 181);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(226, 22);
            this.textBox1.TabIndex = 1;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(482, 376);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(226, 69);
            this.button2.TabIndex = 2;
            this.button2.Text = "DOES THIS NAME SUIT AN INTELLIGENT PERSON?";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(846, 376);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(226, 69);
            this.button3.TabIndex = 3;
            this.button3.Text = "SAY MY NAME IN UPPERCASE";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(835, 97);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(226, 69);
            this.button4.TabIndex = 4;
            this.button4.Text = "HOW MANY SERVICES?";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // ControlLbl
            // 
            this.ControlLbl.BackColor = System.Drawing.Color.RosyBrown;
            this.ControlLbl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ControlLbl.Font = new System.Drawing.Font("Segoe UI Semibold", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ControlLbl.Location = new System.Drawing.Point(839, 181);
            this.ControlLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ControlLbl.Name = "ControlLbl";
            this.ControlLbl.Size = new System.Drawing.Size(222, 114);
            this.ControlLbl.TabIndex = 5;
            // 
            // Minigame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1212, 626);
            this.Controls.Add(this.ControlLbl);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button1);
            this.Name = "Minigame";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label ControlLbl;
    }
}